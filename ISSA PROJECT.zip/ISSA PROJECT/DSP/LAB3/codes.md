```
DIGITAL CONVOLUTION AND FILTERING 



clear
Fe=2e4;
Ne=300;
Nh=50;
th = (0:Nh-1)/Fe
te= (0:Ne-1)/Fe;
ts = (0:Ne+Nh-2)/Fe;


Fc = 200;    // Cut-off frequency
RC = 1 / (2 * %pi * Fc);  // Time constant

// Calculate the filter impulse response (RC)
h = RC * exp(-th / RC);   // Impulse response h(t)
e3= sin(2*%pi*10*Fc*te);
e1 = ones(1, Ne);
e2 = squarewave(2 * %pi * 10*Fc * te);
s1= convol(h,e1);
subplot(3, 1, 1)
plot(ts,s1);
xtitle('reponse imp', 'temps', 'reponse');
subplot(3, 1, 2);
s2= convol(h,e2);
plot(ts,s2);
xtitle('reponse imp', 'temps', 'reponse');
subplot(3, 1, 3);
s3= convol(h,e3);
plot(ts,s3);
xtitle('reponse imp', 'temps', 'reponse');

```

PART 2 

ANALISYS OF LOW PASS FILTER 

rEQUIRED WORK

```
clear


a=8;Te=1e-3;N=128;Fe=1/Te;
//
f=(0:N-1)/N
//
z=poly(0,'z');
//
h1=1+z;
//
h2=-a+z;
//
H=freq(h1,h2,exp(2*%pi*%i*f))
arg_H = atan(imag(H), real(H));
//

////////////////
t=(0:N-1)/Fe
x=5*sin(2*%pi*(Fe/64)*t)
v=3*sin(2*%pi*(Fe/4)*t)
w=x+v
Z=fft(w)
Y=H.*Z// PAY ATTENTION H.*Z POINT PER POINT COMPUTATION 

////////////
subplot(4, 1, 3)
plot(f,abs(Z));
xtitle('FFT');
subplot(4, 1, 2);
plot(t,w);
xtitle('sum vs time')
subplot(4,1,1)
plot(f,arg_H);
xtitle('phase vs freq');
subplot(4, 1, 4)
plot(f,abs(Y));
xtitle('RESPONSE fILTRER Y ');
```