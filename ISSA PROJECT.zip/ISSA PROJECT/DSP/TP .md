AMPLITUDE MODULATION WITH CARRIER 

```
clear
N=500 
Fe=500e3
Te=1/500e3
f1=50e3
f2=4e3
m=1.5
t=(0:N-1)*Te// time vector
f=(0:N-1)*Fe
V=ones(1,N)// heaviside signal generation 1 along N point 
x=sin(2*%pi*f1*t)// the signal 
y=sin(2*%pi*f2*t)// the carrier 
s= V.*(1+m*x).*y// formula for modulation with carrier 
fi=fft(x,-1)// fourrier transform 
se=fft(y,-1)
thi=fft(s,-1)
clf()
subplot(3,1,1)
plot2d(f(N/2:N),1/N*abs(fi(N/2:N)))//(N/2:N) to zoom 
subplot(3,1,2)
plot2d(f(1:N/2),1/N*abs(se(1:N/2)))
subplot(3,1,3)
plot2d(f(1:N/2),1/N*abs(thi(1:N/2)))
```

AMPLITUDE MODULATION WITHOUT CARRIER 

```
clear
N=500 
Fe=500e3
Te=1/500e3
f1=50e3
f2=4e3
t=(0:N-1)*Te
f=(0:N-1)*Fe
x=5*sin(2*%pi*f1*t)
y=2*sin(2*%pi*f2*t)
s= x.*y
fi=fft(x,-1)
se=fft(y,-1)
thi=fft(s,-1)
subplot(3,1,1)
plot2d(f(N/2:N),1/N*abs(fi(N/2:N)))
subplot(3,1,2)
plot2d(f(1:N/2),1/N*abs(se(1:N/2)))
subplot(3,1,3)
plot2d(f(1:N/2),1/N*abs(thi(1:N/2)))
```

TF INVERSE 

```
clear
f=1000
N=1200
Te= 10e-6
Fe=1/Te 
t=(0:N-1)*Te 
fre= (0:N-1)*Fe
s=4*squarewave(2*%pi*f*t)
xo=fft(s,-1)
xi=fft(xo,1)
sine=4*sin(2*%pi*f*t)
k=fft(sine,-1)
kinv=fft(k,1)
figure(1)
clf(1)
subplot (4,1,1)
plot2d(t,k)
subplot (4,1,2)
plot2d(fre,1/N*abs(xo))
subplot (4,1,3)
plot2d(fre,abs(xi))
subplot (4,1,4)
plot2d(t,kinv)
```