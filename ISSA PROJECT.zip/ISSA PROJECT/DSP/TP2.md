EXPO 

```
clear 
N=32
fe=64e3
fx=27.5e3
T0=N/fe // T0 for the window = number point over fe 
Te=1/fe
t=(0:N-1)*T0// time vector by taking account the rect 
f=(0:N-1)*1/T0
x=exp(%i*2*%pi*fx*t)
s=fft(x,-1)
z= T0*sinc(%pi*f*T0)
Y=s.*z
L=fft(Y,1)
clf()
subplot(3,1,1)
plot2d(f,1/N*abs(s))
subplot(3,1,2)
plot2d(f,1/N*abs(Y))
subplot(3,1,3)
plot2d(t,1/N*abs(L))
```

sum of expo

```
clear 
N=1024
f1=26e3
f2=27e3
Fe=64e3
Te=1/Fe
t=(0:N)*Te
f=(0:N)*Fe
g1=exp(%i*2*%pi*f1*t)
g2=exp(%i*2*%pi*f2*t)
G=g1+g2
G1=fft(g2,-1)
F=fft(G,-1)
clf()
subplot(3,1,1)
plot2d(t,G)
subplot(3,1,2)
plot2d(f,1/N*abs(F))
```