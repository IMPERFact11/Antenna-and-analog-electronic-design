```
pART 1 : 
//required work: autocorrelation : 
clear 
//definition of the timestep
N=4096;
t=(0:N-1)*1e-6;
// 
f=1e3
s=5*sin(2*%pi*f*t);
SB = 1; // Puissance du bruit
Ps=(5^2)/2;
Pn=Ps/SB;
Ns= sqrt(Pn) * rand(1, N, "normal");
y= s+Ns ;
cor = corr(y,N);
clf();
subplot(3,1,1)
plot2d(t,s);//rect=[-10,0,15,6]
xtitle("signal s") 
subplot(3,1,2)
plot2d3(t,y);//rect=[-10,0,15,6]
xtitle("signal y"); 
subplot(3,1,3)
plot2d3(cor);//rect=[-10,0,15,6]
xtitle("corre"); 
```

Part 2: 

```
```