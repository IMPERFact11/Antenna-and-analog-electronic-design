```
clear
// Paramètres du signal
fe = 64000;  // Fréquence d'échantillonnage en Hz (64 kHz)

N = 32;      // Nombre d'échantillons
fx = 26000;   // Fréquence du signal en Hz (26 kHz)

// Générer le vecteur de temps
t = 0:1/fe:(N-1)/fe;

// Générer le signal s
s = exp(%i * 2 * %pi * fx * t);

// Calcul de la transformée de Fourier
S = fft(s);

// Calcul des fréquences correspondantes
fre = fe * (0:N-1) / N;

// Affichage du résultat
clf;
subplot(3, 1, 1)
plot(fre, abs(S));
xtitle('Transformée de Fourier du signal s', 'Fréquence (Hz)', 'Amplitude');
To=(N-1)/fe;
y=To*sinc(%pi*(fre-fx)*To);
subplot(3, 1, 2);
plot(fre,y);
```