#### ADVISE

for Kicad

careful on power output wire it

elemnt should not be to close 200mm TO AVOID SHOT CUT

track width 120 µm (use constraint)

care about

save gerber file

capacitor never between power source and an out put

TO JOIN THE GROUND

use filled zone

pick the label you want to join (GND)

![image (2).png](.attachments.247857701/image%20%282%29.png)  
![image (3).png](.attachments.247857701/image%20%283%29.png)NODE RED 

MQQT 

THINGS BOARD 